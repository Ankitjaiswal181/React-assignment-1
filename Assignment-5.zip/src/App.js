import logo from './logo.svg';
import './App.css';
import TodoList from './Component/TodoList';

function App() {
  return (
    <div className="App">
    <TodoList/>
    <hr/>
    </div>
  );
}

export default App;
