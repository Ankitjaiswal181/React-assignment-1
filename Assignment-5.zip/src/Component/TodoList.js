import React,{useState} from 'react'
import './TodoList.css'

const TodoList = () => {
    const [input,setInput]=useState('');
    const handleSubmit=e=>{
        e.preventDefault();
        setInput(e.target.value)
    }
    return (
        <div className='d-flex form '> 
            <form className='todo-form d-flex' onSubmit={handleSubmit}>
            <input 
            type="text"
            placeholder="What will you do today?"
            value={input}
            onChange={input}
            name="text"
            className='todo-input'/>
            <button className="todo-button btn-primary">ADD</button>
            </form>
            
        </div>
    )
}

export default TodoList
